// headerNav.js
(function () {
    var menuBtn = document.getElementById('menuBtn');
    menuBtn.onclick = function () {
        var menu = document.getElementById('login-wrap_nav');
        // alert(menu.style.height)
        if (menu.style.height == '0' || menu.style.height == '0px' || menu.style.height == '') {
            menu.style.height = '200%';
            // menu.style.opacity = '0';
            // alert('auto')
        } else {
            // alert('0px')
            // menu.style.opacity = '1';
            menu.style.height = '0'
        }
    }
})();